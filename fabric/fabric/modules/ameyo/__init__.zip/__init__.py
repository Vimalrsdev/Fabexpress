"""
------------------------
Ameyo module
The module deals with the integration of the Ameyo ticketing service.
(third-party library)
------------------------
Coded by: Krishna Prasad K
© Jyothy Fabricare Services LTD.
------------------------
"""

import requests
import json
import inspect

from fabric import db
from fabric.blueprints.delivery_app.queries import get_est_delivery_date, update_est_delivery_date, \
    set_max_est_delivery_date
from fabric.generic.classes import CallSP
from fabric.generic.functions import get_current_date, get_today
from fabric.generic.loggers import error_logger, info_logger
from fabric.modules.models import Order, OrderGarment, Complaint, CustomerAddres, State, City, PickupRequest, \
    PickupTimeSlot, OrderInstruction, Customer, FabPickupTimeSlots
from fabric.settings.project_settings import LOCAL_DB, SERVER_DB
from sqlalchemy import text
from flask import request
from fabric.generic.classes import SerializeSQLAResult


def add_complaint(customer_details, ameyo_customer_id, egrn, allowed_complaint_garment_list):
    """
    Function for generating a complaint for an order garment.
    First call the Ameyo API then create a complaint with CRM.
    @param allowed_complaint_garment_list: List of garments with the complaint details that has no previous complaints available.
    @param customer_details:
    @param ameyo_customer_id:
    @param egrn
    @return: Dict variable consisting of status and comments.
    """

    complaint_created = False
    comments = []

    # Calling the Ameyo API to create a ticket.
    ticket = create_ticket(customer_details.CustomerName, customer_details.MobileNo,
                           customer_details.CustomerCode,
                           ameyo_customer_id, egrn)

    # Getting city code and state code.
    address_essentials = db.session.query(CustomerAddres.CityCode, State.StateCode).join(City,
                                                                                         CustomerAddres.CityCode == City.CityCode).join(
        State,
        City.StateCode == State.StateCode).filter(
        CustomerAddres.CustomerId == customer_details.CustomerId).all()

    if ticket is not None:
        # Received the response the API.
        if ticket['ticketId']:
            # Successfully generated a ticket id.
            # Saving the complaint details into Complaints table.

            # Each garment have to have each entries in the complaints table.
            for complaint_garment in allowed_complaint_garment_list:
                already_complaint = db.session.query(Complaint).filter(Complaint.TagId == complaint_garment['tag_id']).one_or_none()
                if already_complaint is None:
                    # New Complaint object.
                    new_complaint = Complaint(
                        AmeyoTicketId=ticket['ticketId'],
                        JFSLTicketId=ticket['customId'],
                        TicketSubject=ticket['subject'],
                        AmeyoTicketSourceType=ticket['sourceType'],
                        AmeyoTicketStatus=ticket['externalState'],
                        ClientId=customer_details.CustomerCode,
                        MobileNo=customer_details.MobileNo,
                        ComplaintDate=get_current_date(),
                        BranchCode=customer_details.BranchCode,
                        BrandCode='PCT0000001',
                        ComplaintType=complaint_garment['complaint_type'],
                        EGRN=egrn,
                        ComplaintDesc=complaint_garment['complaint_remarks'],
                        AssignedDept='Operations',
                        TagId=complaint_garment['tag_id'],
                        CityCode=address_essentials[0].CityCode,
                        StateCode=address_essentials[0].StateCode,
                        CampaignId=ticket['campaignId'],
                        QueueId=ticket['queueId'],
                        AssignedUserId=ticket['assignedUserId'],
                        RecordCreatedDate=get_current_date(),
                        RecordLastUpdatedDate=get_current_date(),
                        CRMComplaintStatus='Active'
                    )

                    try:
                        # Inserting the new garment complaint in the DB.
                        db.session.add(new_complaint)
                        db.session.commit()
                    except Exception as e:
                        error_logger(f'Ameyo: {inspect.stack()[0].function}()').error(e)
                else:
                    try:
                        already_complaint.AmeyoTicketId = ticket['ticketId']
                        already_complaint.JFSLTicketId = ticket['customId']
                        already_complaint.TicketSubject = ticket['subject']
                        already_complaint.AmeyoTicketSourceType = ticket['sourceType']
                        already_complaint.ComplaintDate = get_current_date()
                        already_complaint.ComplaintType = complaint_garment['complaint_type']
                        already_complaint.ComplaintDesc = complaint_garment['complaint_remarks']
                        already_complaint.RecordLastUpdatedDate = get_current_date()
                        # update the garment complaint in the DB.
                        db.session.commit()
                    except Exception as e:
                        error_logger(f'Ameyo: {inspect.stack()[0].function}()').error(e)

            # After adding generating the complaint, inform POS's CRM about the complaint.
            query = f"EXEC {LOCAL_DB}.dbo.usp_CREATE_CRM_COMPLAINT_FROM_MOBILE_APP @AMEYOTICKETID_FOR_CRM_COMPLAINT='{ticket['ticketId']}'"
            db.engine.execute(text(query).execution_options(autocommit=True))
            complaint_created = True
        else:
            comments.append('Failed to generate Ameyo Ticket Id.')
    else:
        comments.append('Failed to get the response from Ameyo.')

    if complaint_created:
        # At least one complaint is generated.
        return {'status': True, 'comments': comments}
    else:
        return {'status': False, 'comments': comments}


def create_ticket(customer_name, mobile_number, customer_code, ameyo_customer_id, egrn):
    """
    Function for calling the Ameyo API for creating a ticket.
    @param customer_name: 
    @param mobile_number: 
    @param customer_code: 
    @param ameyo_customer_id: Ameyo customer id
    @param egrn:
    @return: Ameyo API response.
    """

    body = {'subject': f'Complaint Related to EGRN: {egrn}', 'messageText': 'test complaint..',
            'priority': 'LOW', 'externalState': 'COMPLAINT','sourceType': 'CUSTOMER_PORTAL',
            'queueId': '71',
            'customerInfo': {'name': f'{customer_name}', 'phone1': f'{mobile_number}', 'custom_id': f'{customer_code}'},
            'customerId': f'{ameyo_customer_id}', 'customFields': {'d306-5ef767f6-cf-0': 'crm_portal'}}

    # URL for raising a complaint API.
    api_url = "https://jfslcall.fabricspa.com:8443/ameyorestapi/tickets"

    headers = {'Content-Type': 'application/json', 'Authorization': 'fecace70bf6ea0c4'}

    response = requests.post(api_url, data=json.dumps(body), headers=headers)

    # Response in dict
    response = json.loads(response.text)
    log_data = {
        'rewash_response': response,
        'body': body

    }
    info_logger(f'Route: {request.path}').info(json.dumps(log_data))
    return response


def get_ameyo_customer_id(mobile_number):
    """
    Function for getting the ameyo customer code. If no ameyo customer code has been found,
    then the complaint can not be raised.
    @param mobile_number:
    @return: True if the ameyo customer id is found, else False.
    """

    query = f"EXEC GetAmeyoCustomerId @MobileNumber='{mobile_number}'"
    ameyo_customer_id = CallSP(query).execute().fetchone()
    return_data = None
    if ameyo_customer_id.get('AmeyoCustomerId') is not None:
        if ameyo_customer_id['AmeyoCustomerId'] != 'NA':
            # A valid Ameyo customer Id has been found.
            return_data = ameyo_customer_id['AmeyoCustomerId']
    return return_data


def check_complaint_garment(tag_id):
    """
    Function to check whether a particular tag no has complaint or not. (if any)
    @param tag_id: TagId of the garment.
    @return: A dict variable contains complaint flag and rewash count (if any).
    """
    result = {'Complaint': False, 'RewashCount': 0}
    try:
        order_details = db.session.query(OrderGarment.OrderId, Order.EGRN).join(Order,
                                                                                OrderGarment.OrderId == Order.OrderId).filter(
            OrderGarment.TagId == tag_id, Order.IsDeleted == 0).one_or_none()

        if order_details is not None:
            query = f"EXEC {LOCAL_DB}.[dbo].[USP_GET_REWASH_or_CRM_COMPLAINT_COUNT_BASED_ON_EGRN] '{order_details.EGRN}'"
            complaint_history = CallSP(query).execute().fetchall()

            if len(complaint_history) > 0:
                # Complaint history found.
                for complaint in complaint_history:
                    if complaint['TAGNO'] == tag_id:
                        # A match found.
                        result['Complaint'] = True
                        result['RewashCount'] = complaint['REWASHCOUNT']
            else:
                # No complaints found for this Tag Id.
                result = {'Complaint': False, 'RewashCount': 0}
    except Exception as e:
        error_logger(f'Ameyo: {inspect.stack()[0].function}()').error(e)

    return result


def get_complaints_from_egrn(egrn):
    """
    Getting the complaints based on given EGRN.
    @param egrn:
    @return: SP result
    """
    query = f"EXEC {LOCAL_DB}.[dbo].[USP_GET_REWASH_or_CRM_COMPLAINT_COUNT_BASED_ON_EGRN] '{egrn}'"
    complaint_history = CallSP(query).execute().fetchall()
    return complaint_history


def rewash(order_details, rewash_garment_list):
    """
    Function to rewash the garments.
    @param order_details:
    @param rewash_garment_list:
    @return: True if successfully rewashed, False if not.
    """
    rewashed = False
    time_slot_id = None
    time_slot_from = None
    time_slot_to = None
    permit_to_rewash = True

    # Getting the time slot details.
    if order_details.PickupRequestId is not None:
        # This is a normal order, not a walk in.
        # Select the time slots from this pickup request row.
        pickup_request_details = db.session.query(PickupRequest).filter(
            PickupRequest.PickupRequestId == order_details.PickupRequestId).one_or_none()
        if pickup_request_details is not None:
            time_slot_id = pickup_request_details.PickupTimeSlotId
            time_slot_from = pickup_request_details.TimeSlotFrom
            time_slot_to = pickup_request_details.TimeSlotTo
    else:
        # This is a walk in order. So no pickup request id will be present.
        # Getting the time slots from the pickup requests table.
        time_slot = db.session.query(PickupTimeSlot).filter(PickupTimeSlot.BranchCode == order_details.BranchCode,
                                                            PickupTimeSlot.DefaultFlag == 1, PickupTimeSlot.IsActive == 1).one_or_none()

        if time_slot is not None:
            time_slot_id = time_slot.PickupTimeSlotId
            time_slot_from = time_slot.TimeSlotFrom
            time_slot_to = time_slot.TimeSlotTo
    if order_details.DeliveryAddressId is not None:
        address_id = order_details.DeliveryAddressId
    else:
        address = db.session.query(DeliveryRequest).filter(DeliveryRequest.OrderId == order_details.OrderId).one_or_none()
        address_id = address.CustAddressId

    # Setting up the new PickupRequest object.
    new_pickup_request = PickupRequest(
        CustomerId=order_details.CustomerId,
        PickupDate=get_today(),
        BranchCode=order_details.BranchCode,
        PickupTimeSlotId=time_slot_id,
        TimeSlotFrom=time_slot_from,
        TimeSlotTo=time_slot_to,
        CustAddressId=address_id,
        PickupSource='Rewash',
        PickupStatusId=2,
        DUserId=order_details.DUserId,
        RecordCreatedDate=get_current_date(),
        RecordLastUpdatedDate=get_current_date()
    )

    # Saving the new pickup request.
    db.session.add(new_pickup_request)
    db.session.commit()

    # After creating the pickup request data, generate BookingId.
    query = f"EXEC {LOCAL_DB}.dbo.[USP_INSERT_ADHOC_PICKUP_FROM_MOBILEAPP_TO_FABRICARE] @PickUprequestId={new_pickup_request.PickupRequestId}"
    db.engine.execute(text(query).execution_options(autocommit=True))

    # Getting the BookingId. If BookingId is not generated,rewash order can't be created.
    booking_id = db.session.query(PickupRequest.BookingId).filter(
        PickupRequest.PickupRequestId == new_pickup_request.PickupRequestId).one_or_none()
    if booking_id is not None:
        if booking_id.BookingId is not None:
            booking_id = booking_id.BookingId
    else:
        # BookingId is not generated.
        permit_to_rewash = False

    if permit_to_rewash:
        address_id = None
        if order_details.PickupAddressId is None:
            # This will be a walk-in order. In case of a walk in order, select the address 1
            # of the customer.
            customer_address = db.session.query(CustomerAddres.CustAddressId).filter(
                CustomerAddres.CustomerId == order_details.CustomerId, CustomerAddres.AddressName == 'Address 1').limit(
                1).one_or_none()

            if customer_address is not None:
                # A valid first address is found for the customer.
                address_id = customer_address.CustAddressId
            else:
                # No valid first address found for the customer. Rewash can not be performed.
                info_logger(f'Rewash - No valid first address found for the customer (Id: {order_details.CustomerId}).')
                return False

        else:
            address_id = order_details.PickupAddressId

        # Creating a new re wash order.
        # Basic, discount and tax amounts will be 0.
        new_rewash_order = Order(
            OrderCode=order_details.OrderCode,
            EGRN=None,
            CustomerId=order_details.CustomerId,
            BranchCode=order_details.BranchCode,
            PickupRequestId=new_pickup_request.PickupRequestId,
            BookingId=booking_id,
            PickupAddressId=address_id,
            DeliveryAddressId=address_id,
            PickupDate=get_today(),
            DUserId=order_details.DUserId,
            Remarks=order_details.Remarks,
            # DiscountCode=order_details.DiscountCode,
            DiscountCode=None,
            CouponCode=order_details.CouponCode,
            LoyalityPoints=order_details.LoyalityPoints,
            # Rewash type.
            OrderTypeId=2,
            OrderDate=get_current_date(),
            EstDeliveryDate=None,
            BasicAmount=0,
            Discount=0,
            ServiceTaxAmount=0,
            OrderAmount=0,
            OrderStatusId=1
        )

        # Adding the new rewash order into the DB.
        db.session.add(new_rewash_order)
        db.session.commit()

        new_order_id = new_rewash_order.OrderId

        # Marking the pickup request as 3, i.e. completed.
        pickup_request = db.session.query(PickupRequest).filter(
            PickupRequest.PickupRequestId == new_pickup_request.PickupRequestId).one_or_none()
        if pickup_request is not None:
            pickup_request.PickupStatusId = 3
            db.session.commit()

        # After creating the rewash order, create a new order garment for each rewash garments.
        for rewash_garment in rewash_garment_list:

            order_garment_details = db.session.query(OrderGarment).filter(
                OrderGarment.OrderGarmentId == rewash_garment['order_garment_id']).one_or_none()

            if order_details is not None:
                # Same garment needs to be inserted again as a new order garment.
                # Basic, discount and tax amounts will be 0.
                new_order_garment = OrderGarment(
                    OrderId=new_order_id,
                    GarmentId=order_garment_details.GarmentId,
                    ServiceTypeId=order_garment_details.ServiceTypeId,
                    ServiceTatId=order_garment_details.ServiceTatId,
                    TagId=None,
                    GarmentStatusId=1,
                    GarmentBrand=order_garment_details.GarmentBrand,
                    GarmentColour=order_garment_details.GarmentColour,
                    GarmentSize=order_garment_details.GarmentSize,
                    QCStatus=None,
                    CRMComplaintId=order_garment_details.CRMComplaintId,
                    BasicAmount=0,
                    Discount=0,
                    ServiceTaxAmount=0,
                    EstDeliveryDate=None
                )

                # Adding the garment into the DB.
                db.session.add(new_order_garment)
                db.session.commit()

                # After adding the garment id, calculate the EstDeliveryDate value and update it.
                est_delivery = get_est_delivery_date(new_order_garment.OrderGarmentId)

                # Updating the EstDeliveryDate in the OrderGarments table.
                update_est_delivery_date(new_order_garment.OrderGarmentId, est_delivery)

                # Updating the EstDeliveryDate of the Orders table.
                set_max_est_delivery_date(new_order_id)

        # Generating an EGRN for the new rewash order.
        query = f"EXEC {SERVER_DB}.dbo.App_OrderCreation_Detail @branchcode='{order_details.BranchCode}',@orderid={new_order_id}"
        egrn = CallSP(query).execute().fetchone()
        if egrn:
            egrn = egrn['EGRN']
            # Updating the order with the EGRN.
            try:
                # Saving the order with the newly generated EGRN.
                new_order_details = db.session.query(Order).filter(
                    Order.OrderId == new_order_id).one_or_none()
                if new_order_details is not None:
                    # Saving the EGRN to the rewash order.
                    new_order_details.EGRN = egrn
                    db.session.commit()
                    rewashed = True
            except Exception as e:
                db.session.rollback()
                error_logger(f'Ameyo: {inspect.stack()[0].function}()').error(e)

    return rewashed

def adhoc_rewash(complaint_garment_list, user_id, time_slot_id, address_id, branch_code, customer_id, booking_id, pickup_request_id, lat, longitude, geo_location):
    """
    Function to rewash the garments.
    @param complaint_garment_list:
    @param user_id:
    @param time_slot_id:
    @param branch_code:
    @param customer_id:
    @param address_id
    @param booking_id
    @return: True if successfully rewashed, False if not.
    """
    final_rewash = []
    time_slot = db.session.query(PickupTimeSlot.PickupTimeSlotId,
                                     PickupTimeSlot.TimeSlotFrom,
                                     PickupTimeSlot.TimeSlotTo).filter(
            PickupTimeSlot.BranchCode == branch_code,
            PickupTimeSlot.DefaultFlag == 1,
            PickupTimeSlot.IsActive == 1
        ).first()

    if time_slot is None:
        # No time slot present, so try with DefaultFlag.
        time_slot = db.session.query(PickupTimeSlot.PickupTimeSlotId,
                                     PickupTimeSlot.TimeSlotFrom,
                                     PickupTimeSlot.TimeSlotTo).filter(
            PickupTimeSlot.BranchCode == branch_code,
            PickupTimeSlot.DefaultFlag == 1,
            PickupTimeSlot.IsActive == 1
        ).first()

    permit_to_rewash = True
    if booking_id is None:
        # pickup_request_details = db.session.query(PickupRequest).filter(PickupRequest.PickupRequestId == pickup_request_id).one_or_none()
        # if pickup_request_details.BookingId is not None:
        if pickup_request_id is None:
            # # Setting up the new PickupRequest object.
            new_pickup_request = PickupRequest(
                CustomerId=customer_id,
                PickupDate=get_today(),
                BranchCode=branch_code,
                PickupTimeSlotId=time_slot.PickupTimeSlotId,
                TimeSlotFrom=time_slot.TimeSlotFrom,
                TimeSlotTo=time_slot.TimeSlotTo,
                CustAddressId=address_id,
                PickupSource='Rewash',
                PickupStatusId=2,
                DUserId=user_id,
                RecordCreatedDate=get_current_date(),
                RecordLastUpdatedDate=get_current_date(),
                Lat=lat,
                Long=longitude,
                GeoLocation=geo_location
            #     CompletedDate=get_today(),
            #     CompletedBy = user_id
            )
            # # Saving the new pickup request.
            db.session.add(new_pickup_request)
            db.session.commit()
            # pickup_request_details.RecordLastUpdatedDate = get_current_date()
            # # pickup_request_details.PickupStatusId = 2
            # db.session.commit()

            # After creating the pickup request data, generate BookingId.
            # query = f"EXEC {LOCAL_DB}.dbo.[USP_INSERT_ADHOC_PICKUP_FROM_MOBILEAPP_TO_FABRICARE] @PickUprequestId={new_pickup_request.PickupRequestId}"
            # db.engine.execute(text(query).execution_options(autocommit=True))
            # Getting the BookingId. If BookingId is not generated,rewash order can't be created.
            pickup_details = db.session.query(PickupRequest).filter(
                PickupRequest.PickupRequestId == new_pickup_request.PickupRequestId).one_or_none()
            pickup_request_id = new_pickup_request.PickupRequestId
        else:
            # query = f"EXEC {LOCAL_DB}.dbo.[USP_INSERT_ADHOC_PICKUP_FROM_MOBILEAPP_TO_FABRICARE] @PickUprequestId={pickup_request_id}"
            # db.engine.execute(text(query).execution_options(autocommit=True))
            pickup_details = db.session.query(PickupRequest).filter(
                PickupRequest.PickupRequestId == pickup_request_id).one_or_none()

    else:
        pickup_details = db.session.query(PickupRequest).filter(PickupRequest.BookingId == booking_id).one_or_none()
        # pickup_details.RecordLastUpdatedDate = get_current_date()
        # pickup_details.PickupStatusId = 2
        # pickup_details.CompletedDate = get_today()
        # pickup_details.CompletedBy = user_id
        # db.session.commit()
        pickup_request_id = pickup_details.PickupRequestId
    if pickup_details is not None:
        permit_to_rewash = True
        # if pickup_details.BookingId is not None:
        #     booking_id = pickup_details.BookingId
    else:
        # BookingId is not generated.
        permit_to_rewash = False

    if permit_to_rewash:
        order_details = db.session.query(Order).filter(Order.PickupRequestId == pickup_request_id, Order.IsDeleted == 0).one_or_none()
        if order_details is None:
            new_rewash_order = Order(
                # OrderCode=order_details.OrderCode,
                EGRN=None,
                CustomerId=customer_id,
                BranchCode=branch_code,
                PickupRequestId=pickup_request_id,
                # BookingId=booking_id,
                PickupAddressId=address_id,
                DeliveryAddressId=address_id,
                PickupDate=get_today(),
                DUserId=user_id,
                # Rewash type.
                OrderTypeId=2,
                OrderDate=get_current_date(),
                EstDeliveryDate=None,
                BasicAmount=0,
                Discount=0,
                ServiceTaxAmount=0,
                OrderAmount=0,
                OrderStatusId=1
            )
            # Adding the new rewash order into the DB.
            db.session.add(new_rewash_order)
            db.session.commit()

            new_order_id = new_rewash_order.OrderId
        else:
            new_order_id = order_details.OrderId

            order_garments = db.session.query(OrderGarment.OrderGarmentId).filter(OrderGarment.OrderId == new_order_id).all()
            if order_garments is not None:
                order_garments = SerializeSQLAResult(order_garments).serialize()
                log_data = {
                    'already present garments': order_garments
                    }
                info_logger(f'Route: {request.path}').info(json.dumps(log_data))
                for garments in order_garments:
                    order_garment_id = garments['OrderGarmentId']
                    order_garment = db.session.query(OrderGarment).filter(OrderGarment.OrderGarmentId == order_garment_id).one_or_none()
                    order_garment.IsDeleted = 1
                    db.session.commit()
            else:
                pass

        # Marking the pickup request as 3, i.e. completed.
        pickup_request = db.session.query(PickupRequest).filter(
            PickupRequest.PickupRequestId == pickup_request_id).one_or_none()
        if pickup_request is not None:
            pickup_request.PickupStatusId = 2
            pickup_request.RecordLastUpdatedDate = get_current_date()
            db.session.commit()

        # After creating the rewash order, create a new order garment for each rewash garments.
        for rewash_garment in complaint_garment_list:
            new_rewash_details = {}
            order_garment_details = db.session.query(OrderGarment).filter(
                OrderGarment.OrderGarmentId == rewash_garment['order_garment_id']).one_or_none()
            if order_garment_details is not None:
                # if rewash_garment['crm_complaint_status']:
                #     complaint_details = db.session.query(Complaint).filter(
                #         Complaint.Id == rewash_garment['complaint_id']).one_or_none()
                #     crm_complaint_id = complaint_details.CRMComplaintId
                # else:
                #     crm_complaint_id = rewash_complaint(rewash_garment, customer_id)

                # Same garment needs to be inserted again as a new order garment.
                # Basic, discount and tax amounts will be 0.
                new_order_garment = OrderGarment(
                    OrderId=new_order_id,
                    GarmentId=order_garment_details.GarmentId,
                    ServiceTypeId=order_garment_details.ServiceTypeId,
                    ServiceTatId=order_garment_details.ServiceTatId,
                    TagId=None,
                    GarmentStatusId=1,
                    GarmentBrand=order_garment_details.GarmentBrand,
                    GarmentColour=order_garment_details.GarmentColour,
                    GarmentSize=order_garment_details.GarmentSize,
                    QCStatus=None,
                    # CRMComplaintId=crm_complaint_id,
                    BasicAmount=0,
                    Discount=0,
                    ServiceTaxAmount=0,
                    EstDeliveryDate=None
                )
                # Adding the garment into the DB.
                db.session.add(new_order_garment)
                db.session.commit()

                new_rewash_details['new_garment_id'] = new_order_garment.OrderGarmentId
                new_rewash_details['old_garment_id'] = rewash_garment['order_garment_id']
                new_rewash_details['complaint_status'] = rewash_garment['crm_complaint_status']
                new_rewash_details['complaint_id'] = rewash_garment['complaint_id']
                final_rewash.append(new_rewash_details)
                vas_details = db.session.query(OrderInstruction).filter(
                    OrderInstruction.OrderId == order_garment_details.OrderId,
                    OrderInstruction.OrderGarmentId == order_garment_details.OrderGarmentId).all()
                if vas_details is not None:
                    for vas in vas_details:
                        new_instruction = OrderInstruction(OrderId=new_order_id,
                                                           OrderGarmentId=new_order_garment.OrderGarmentId,
                                                           InstructionId=vas.InstructionId, IsDeleted=0)
                        db.session.add(new_instruction)
                        db.session.commit()

                # After adding the garment id, calculate the EstDeliveryDate value and update it.
                est_delivery = get_est_delivery_date(new_order_garment.OrderGarmentId)

                # Updating the EstDeliveryDate in the OrderGarments table.
                update_est_delivery_date(new_order_garment.OrderGarmentId, est_delivery)

                # Updating the EstDeliveryDate of the Orders table.
                set_max_est_delivery_date(new_order_id)

    return {"new_order_id": new_order_id, "final_rewash": final_rewash}

def rewash_complaint(complaint_garment, customer_id):
    complaint_status = False
    complaint_details = db.session.query(Complaint).filter(
        Complaint.Id == complaint_garment['complaint_id']).one_or_none()
    if complaint_details.AmeyoTicketId == None:
        if complaint_details is not None:
            egrn = db.session.query(Order.EGRN).join(OrderGarment,
                                                     OrderGarment.OrderId == Order.OrderId).filter(
                OrderGarment.OrderGarmentId == complaint_garment['old_garment_id']
            ).one_or_none()
            customer_details = db.session.query(Customer.CustomerId, Customer.CustomerCode,
                                                Customer.CustomerName,
                                                Customer.MobileNo, Customer.BranchCode).filter(
                Customer.CustomerId == customer_id).one_or_none()
            ameyo_customer_id = get_ameyo_customer_id(customer_details.MobileNo)
            if ameyo_customer_id:
                # Calling the Ameyo API to create a ticket.
                ticket = create_ticket(customer_details.CustomerName, customer_details.MobileNo,
                                       customer_details.CustomerCode,
                                       ameyo_customer_id, egrn)
                if ticket is not None:
                    # Received the response the API.
                    if ticket['ticketId']:
                        try:
                            complaint_details.AmeyoTicketId = ticket['ticketId']
                            complaint_details.JFSLTicketId = ticket['customId']
                            complaint_details.TicketSubject = ticket['subject']
                            complaint_details.AmeyoTicketSourceType = ticket['sourceType']
                            complaint_details.AmeyoTicketStatus = ticket['externalState']
                            complaint_details.CampaignId = ticket['campaignId']
                            complaint_details.QueueId = ticket['queueId']
                            complaint_details.AssignedUserId = ticket['assignedUserId']
                            try:
                                # Inserting the new garment complaint in the DB.
                                db.session.commit()
                            except Exception as e:
                                error_logger(f'Ameyo: {inspect.stack()[0].function}()').error(e)
                        except Exception as e:
                            error_logger(f'Ameyo: {inspect.stack()[0].function}()').error(e)

                    query = f"EXEC {LOCAL_DB}.dbo.usp_CREATE_CRM_COMPLAINT_FROM_MOBILE_APP " \
                            f"@AMEYOTICKETID_FOR_CRM_COMPLAINT='{ticket['ticketId']}' "
                    log_data = {
                            'SP-update-complaintId': query
                            }
                    info_logger(f'Route: {request.path}').info(json.dumps(log_data))
                    db.engine.execute(text(query).execution_options(autocommit=True))
    else:
        query = f"EXEC {LOCAL_DB}.dbo.usp_CREATE_CRM_COMPLAINT_FROM_MOBILE_APP " \
                f"@AMEYOTICKETID_FOR_CRM_COMPLAINT='{complaint_details.AmeyoTicketId}'"
        log_data = {
            'SP-update-complaintId': query
        }
        info_logger(f'Route: {request.path}').info(json.dumps(log_data))
        db.engine.execute(text(query).execution_options(autocommit=True))
    complaint_details = db.session.query(Complaint).filter(
        Complaint.Id == complaint_garment['complaint_id']).one_or_none()

    return complaint_details.CRMComplaintId

def same_order_complaint(single_ameyo_orders, customer_id):
    complaint_status = False
    customer_details = db.session.query(Customer.CustomerId, Customer.CustomerCode,
                                        Customer.CustomerName,
                                        Customer.MobileNo, Customer.BranchCode).filter(
        Customer.CustomerId == customer_id).one_or_none()
    ameyo_customer_id = get_ameyo_customer_id(customer_details.MobileNo)
    if ameyo_customer_id:

        for single_order in single_ameyo_orders:

            egrn = db.session.query(Order.EGRN, Order.OrderId).filter(
                Order.OrderId == single_order['order_id']
            ).one_or_none()
            ticket = create_ticket(customer_details.CustomerName, customer_details.MobileNo,
                                   customer_details.CustomerCode,
                                   ameyo_customer_id, egrn.EGRN)
            if ticket is not None:
                # Received the response the API.
                if ticket['ticketId']:
                    complaint_status = True
                    for complaint_id in single_order["complaint_id"]:
                        try:
                            complaint_details = db.session.query(Complaint).filter(
                                Complaint.Id == complaint_id).one_or_none()

                            complaint_details.AmeyoTicketId = ticket['ticketId']
                            complaint_details.JFSLTicketId = ticket['customId']
                            complaint_details.TicketSubject = ticket['subject']
                            complaint_details.AmeyoTicketSourceType = ticket['sourceType']
                            complaint_details.AmeyoTicketStatus = ticket['externalState']
                            complaint_details.CampaignId = ticket['campaignId']
                            complaint_details.QueueId = ticket['queueId']
                            complaint_details.AssignedUserId = ticket['assignedUserId']
                            try:
                                # Inserting the new garment complaint in the DB.
                                db.session.commit()
                            except Exception as e:
                                error_logger(f'Ameyo: {inspect.stack()[0].function}()').error(e)
                        except Exception as e:
                            error_logger(f'Ameyo: {inspect.stack()[0].function}()').error(e)

                    query = f"EXEC {LOCAL_DB}.dbo.usp_CREATE_CRM_COMPLAINT_FROM_MOBILE_APP " \
                            f"@AMEYOTICKETID_FOR_CRM_COMPLAINT='{ticket['ticketId']}' "
                    db.engine.execute(text(query).execution_options(autocommit=True))
                    log_data = {
                        'same_order_ameyo': query,
                    }
                    info_logger(f'Route: {request.path}').info(json.dumps(log_data))
    return complaint_status

def active_or_not(complaint_id):
    rewash_status = True
    query = f"EXEC {SERVER_DB}.dbo.GetRewashOrderstatus @ComplaintID='{complaint_id}'"
    order_status = CallSP(query).execute().fetchall()
    if order_status is not None:
        for status in order_status:
            if status['OrderStatus'] == 'Active' and status['GarmentStatus'] != 'Transfer in at CDC':
                rewash_status = True
                break
            elif status['OrderStatus'] == 'cancelled' or status['OrderStatus'] == 'Completed' or status['GarmentStatus'] == 'Transfer in at CDC':
                rewash_status = False
    return rewash_status